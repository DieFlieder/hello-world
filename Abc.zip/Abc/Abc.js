var btn1 = document.querySelector("#Monday");
console.dir(btn1);
var Tuesday = document.querySelector("#Tuesday");
console.dir(Tuesday);
var Wednesday = document.querySelector("#Wednesday");
console.dir(Wednesday);
var Thursday = document.querySelector("#Thursday");
console.dir(Thursday);
var Friday = document.querySelector("#Friday");
console.dir(Friday);
var h2 = document.querySelector("#g");
var h3 = document.querySelector("#gg");
var h4 = document.querySelector("#ggg");
var h5 = document.querySelector("#gggg");

btn1.onclick = function() {
	h2.innerText = "1.Основи програмування";
	h3.innerText = "‌2.Фізична культура";
	h4.innerText = "3.Алгоритми і СД";
	h5.innerText = "4.Основи екології";
}
Tuesday.onclick = function() {
	h2.innerText = "1.БЖД";
	h3.innerText = "2.Культурологія";
	h4.innerText = "3.Англійська мова";
	h5.innerText = "";
}
Wednesday.onclick = function() {
	h2.innerText = "1.Архітектура комп'ютерів";
	h3.innerText = "2.Лінійна алгебра та аналітична геометрія";
	h4.innerText = "3.Історія України";
	h5.innerText = "4.Англійська мова/Основи програмування";
}
Thursday.onclick = function() {
	h2.innerText = "1.Вступ до спеціальності / Алгоритми і СД ";
	h3.innerText = "2.Фізична культура";
	h4.innerText = "3.Лінійна алгебра та аналітична геометрія";
	h5.innerText = "4.Архітектура комп'ютерів";
}
Friday.onclick = function() {
	h2.innerText = "1.Історія України ";
	h3.innerText = "2.Основи програмування";
	h4.innerText = "3.Алгоритми і СД";
	h5.innerText = "";
}







